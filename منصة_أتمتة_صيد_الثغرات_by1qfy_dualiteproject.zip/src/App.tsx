import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Login from './components/Login';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-950">
      <Sidebar />
      <main className="flex-1 flex flex-col mr-64">
        <Header onLogout={() => setIsAuthenticated(false)} />
        <div className="flex-1 overflow-y-auto scrollbar-hide">
          <Dashboard />
        </div>
      </main>
    </div>
  );
}

export default App;
