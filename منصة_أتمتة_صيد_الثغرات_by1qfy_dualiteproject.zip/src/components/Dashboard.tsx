import React, { useState } from 'react';
import { Target, AlertTriangle, CheckCircle, Activity } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import { statsData, vulnerabilitiesBySeverity, recentVulnerabilities, Vulnerability } from '../data/mockData';
import Terminal from './Terminal';
import VulnerabilityModal from './VulnerabilityModal';

const StatCard = ({ title, value, icon: Icon, colorClass }: any) => (
  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex items-center">
    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ml-4 ${colorClass}`}>
      <Icon className="w-6 h-6" />
    </div>
    <div>
      <p className="text-sm font-medium text-slate-400 mb-1">{title}</p>
      <h3 className="text-2xl font-bold text-slate-100">{value}</h3>
    </div>
  </div>
);

export default function Dashboard() {
  const [selectedVuln, setSelectedVuln] = useState<Vulnerability | null>(null);

  const chartOptions = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'item' },
    legend: { 
      bottom: '0%', 
      left: 'center', 
      textStyle: { color: '#94a3b8', fontFamily: 'inherit' }
    },
    series: [
      {
        name: 'مستوى الخطورة',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#0f172a',
          borderWidth: 2
        },
        label: { show: false, position: 'center' },
        emphasis: {
          label: { show: true, fontSize: 18, fontWeight: 'bold', color: '#f8fafc' }
        },
        labelLine: { show: false },
        data: vulnerabilitiesBySeverity
      }
    ]
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 mb-1">نظرة عامة على الأهداف</h1>
          <p className="text-sm text-slate-400">ملخص لعمليات الاستطلاع والفحص الحالية.</p>
        </div>
        <button className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold px-4 py-2 rounded-lg transition-colors flex items-center">
          <Activity className="w-4 h-4 ml-2" />
          بدء فحص جديد
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="إجمالي الأهداف" value={statsData.totalTargets} icon={Target} colorClass="bg-blue-500/10 text-blue-400" />
        <StatCard title="فحوصات نشطة" value={statsData.activeScans} icon={Activity} colorClass="bg-emerald-500/10 text-emerald-400" />
        <StatCard title="ثغرات مكتشفة" value={statsData.vulnerabilities} icon={AlertTriangle} colorClass="bg-red-500/10 text-red-400" />
        <StatCard title="ثغرات تم حلها" value={statsData.resolved} icon={CheckCircle} colorClass="bg-purple-500/10 text-purple-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 lg:col-span-1 flex flex-col">
          <h2 className="text-lg font-semibold text-slate-100 mb-4">الثغرات حسب الخطورة</h2>
          <div className="flex-1 min-h-[300px]">
            <ReactECharts option={chartOptions} style={{ height: '100%', width: '100%' }} />
          </div>
        </div>

        {/* Terminal */}
        <div className="lg:col-span-2 h-[400px]">
          <Terminal />
        </div>
      </div>

      {/* Recent Vulnerabilities Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">أحدث الثغرات المكتشفة</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-slate-950/50 text-slate-400 text-sm">
              <tr>
                <th className="px-6 py-4 font-medium">المعرف</th>
                <th className="px-6 py-4 font-medium">الهدف</th>
                <th className="px-6 py-4 font-medium">نوع الثغرة</th>
                <th className="px-6 py-4 font-medium">الخطورة</th>
                <th className="px-6 py-4 font-medium">التاريخ</th>
                <th className="px-6 py-4 font-medium">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-sm">
              {recentVulnerabilities.map((vuln) => (
                <tr 
                  key={vuln.id} 
                  onClick={() => setSelectedVuln(vuln)}
                  className="hover:bg-slate-800/80 transition-colors cursor-pointer"
                >
                  <td className="px-6 py-4 font-mono text-slate-300">{vuln.id}</td>
                  <td className="px-6 py-4 text-slate-300">{vuln.target}</td>
                  <td className="px-6 py-4 text-slate-300">{vuln.type}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${
                      vuln.severity === 'Critical' ? 'bg-red-500/10 border-red-500/20 text-red-400' :
                      vuln.severity === 'High' ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' :
                      vuln.severity === 'Medium' ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400' :
                      'bg-blue-500/10 border-blue-500/20 text-blue-400'
                    }`}>
                      {vuln.severity}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400">{vuln.date}</td>
                  <td className="px-6 py-4">
                    <span className={`flex items-center text-xs font-medium ${
                      vuln.status === 'Open' ? 'text-red-400' : 'text-emerald-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ml-2 ${
                        vuln.status === 'Open' ? 'bg-red-400' : 'bg-emerald-400'
                      }`}></span>
                      {vuln.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <VulnerabilityModal 
        isOpen={!!selectedVuln} 
        onClose={() => setSelectedVuln(null)} 
        vulnerability={selectedVuln} 
      />
    </div>
  );
}
