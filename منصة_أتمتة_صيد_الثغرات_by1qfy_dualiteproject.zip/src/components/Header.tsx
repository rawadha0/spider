import React, { useState } from 'react';
import { Bell, Search, Zap, LogOut } from 'lucide-react';
import { motion } from 'framer-motion';

interface HeaderProps {
  onLogout: () => void;
}

export default function Header({ onLogout }: HeaderProps) {
  const [aiEnabled, setAiEnabled] = useState(true);

  return (
    <header className="h-16 bg-slate-900/50 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex items-center w-96">
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="ابحث عن هدف، ثغرة، أو تقرير..." 
            className="w-full bg-slate-800/50 border border-slate-700 text-sm rounded-full py-2 pr-10 pl-4 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-slate-200 placeholder:text-slate-500"
          />
        </div>
      </div>

      <div className="flex items-center space-x-reverse space-x-6">
        {/* AI Toggle */}
        <div className="flex items-center bg-slate-800/50 rounded-full p-1 border border-slate-700">
          <span className="text-xs font-medium text-slate-400 ml-3 mr-2">تصفية AI</span>
          <button 
            onClick={() => setAiEnabled(!aiEnabled)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${aiEnabled ? 'bg-purple-500' : 'bg-slate-600'}`}
          >
            <motion.span
              layout
              className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"
              style={{ x: aiEnabled ? -2 : -22 }}
            />
          </button>
          {aiEnabled && <Zap className="w-4 h-4 text-purple-400 mr-2 ml-2 animate-pulse" />}
        </div>

        <button className="relative text-slate-400 hover:text-slate-200 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-slate-900"></span>
        </button>

        <div className="flex items-center border-r border-slate-700 pr-6">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
            H
          </div>
          <div className="mr-3">
            <div className="text-sm font-medium text-slate-200">Hunter_0x01</div>
            <div className="text-xs text-slate-500">Pro Member</div>
          </div>
          
          <button 
            onClick={onLogout}
            title="تسجيل الخروج"
            className="mr-6 text-slate-500 hover:text-red-400 transition-colors p-2 hover:bg-slate-800 rounded-lg"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
