import React from 'react';
import { Shield, LayoutDashboard, Target, Activity, FileText, Settings, Cpu } from 'lucide-react';
import { cn } from '../lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'لوحة القيادة', active: true },
  { icon: Target, label: 'الأهداف' },
  { icon: Activity, label: 'الاستطلاع والفحص' },
  { icon: Shield, label: 'الثغرات' },
  { icon: FileText, label: 'التقارير' },
  { icon: Settings, label: 'الإعدادات' },
];

export default function Sidebar() {
  return (
    <aside className="w-64 h-screen bg-slate-900 border-l border-slate-800 flex flex-col fixed right-0 top-0">
      <div className="h-16 flex items-center px-6 border-b border-slate-800">
        <Shield className="w-8 h-8 text-emerald-500 ml-3" />
        <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-l from-emerald-400 to-cyan-400">
          BugBounty Pro
        </span>
      </div>
      
      <div className="p-4 flex-1">
        <div className="text-xs font-semibold text-slate-500 mb-4 px-2 uppercase tracking-wider">القائمة الرئيسية</div>
        <nav className="space-y-1">
          {navItems.map((item, index) => (
            <button
              key={index}
              className={cn(
                "w-full flex items-center px-3 py-2.5 rounded-lg transition-colors duration-200",
                item.active 
                  ? "bg-emerald-500/10 text-emerald-400" 
                  : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              )}
            >
              <item.icon className="w-5 h-5 ml-3" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center mb-2">
            <Cpu className="w-5 h-5 text-purple-400 ml-2" />
            <span className="text-sm font-semibold text-slate-200">محرك الذكاء الاصطناعي</span>
          </div>
          <p className="text-xs text-slate-400 mb-3">يعمل حالياً على تصفية الإيجابيات الكاذبة وتحليل الأنماط.</p>
          <div className="w-full bg-slate-700 rounded-full h-1.5">
            <div className="bg-purple-500 h-1.5 rounded-full w-3/4 animate-pulse"></div>
          </div>
        </div>
      </div>
    </aside>
  );
}
