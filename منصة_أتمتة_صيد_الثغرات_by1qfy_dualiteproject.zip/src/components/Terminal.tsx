import React, { useEffect, useState } from 'react';
import { Terminal as TerminalIcon, Play, Square } from 'lucide-react';
import { terminalLogs } from '../data/mockData';
import { motion } from 'framer-motion';

export default function Terminal() {
  const [logs, setLogs] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(true);

  useEffect(() => {
    if (!isRunning) return;
    
    let currentIndex = 0;
    setLogs([]);

    const interval = setInterval(() => {
      if (currentIndex < terminalLogs.length) {
        setLogs(prev => [...prev, terminalLogs[currentIndex]]);
        currentIndex++;
      } else {
        clearInterval(interval);
        setIsRunning(false);
      }
    }, 800);

    return () => clearInterval(interval);
  }, [isRunning]);

  return (
    <div className="bg-[#0D1117] rounded-xl border border-slate-800 overflow-hidden flex flex-col h-full shadow-lg">
      <div className="h-10 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4">
        <div className="flex items-center">
          <TerminalIcon className="w-4 h-4 text-slate-400 ml-2" />
          <span className="text-xs font-mono text-slate-400">Recon & Scan Engine (Amass + Nuclei)</span>
        </div>
        <div className="flex items-center space-x-reverse space-x-2">
          <button 
            onClick={() => setIsRunning(!isRunning)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 transition-colors"
          >
            {isRunning ? <Square className="w-4 h-4 text-red-400" /> : <Play className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>
      <div className="p-4 font-mono text-sm overflow-y-auto flex-1 scrollbar-hide">
        {logs.map((log, index) => {
          let colorClass = "text-slate-300";
          if (log?.includes("[+]")) colorClass = "text-emerald-400";
          if (log?.includes("[!]")) colorClass = "text-red-400 font-bold";
          if (log?.includes("[-]")) colorClass = "text-yellow-400";
          if (log?.includes("AI Filter")) colorClass = "text-purple-400";

          return (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              key={index} 
              className={`mb-1 ${colorClass}`}
              dir="ltr"
            >
              {log}
            </motion.div>
          );
        })}
        {isRunning && (
          <motion.div 
            animate={{ opacity: [1, 0] }} 
            transition={{ repeat: Infinity, duration: 0.8 }}
            className="w-2 h-4 bg-emerald-400 mt-1"
          />
        )}
      </div>
    </div>
  );
}
