export const statsData = {
  totalTargets: 14,
  activeScans: 3,
  vulnerabilities: 128,
  resolved: 45,
};

export const vulnerabilitiesBySeverity = [
  { value: 5, name: 'حرج (Critical)', itemStyle: { color: '#ef4444' } },
  { value: 18, name: 'عالي (High)', itemStyle: { color: '#f97316' } },
  { value: 42, name: 'متوسط (Medium)', itemStyle: { color: '#eab308' } },
  { value: 63, name: 'منخفض (Low)', itemStyle: { color: '#3b82f6' } },
];

export interface Vulnerability {
  id: string;
  target: string;
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  date: string;
  status: 'Open' | 'Resolved';
  description: string;
  remediation: string;
}

export const recentVulnerabilities: Vulnerability[] = [
  { 
    id: 'VULN-001', 
    target: 'api.target.com', 
    type: 'SQL Injection', 
    severity: 'Critical', 
    date: '2023-10-25', 
    status: 'Open',
    description: 'ثغرة حقن قواعد البيانات (SQLi) تسمح للمهاجم بتنفيذ أوامر SQL خبيثة للوصول إلى البيانات الحساسة أو تعديلها أو حذفها من قاعدة البيانات.',
    remediation: 'استخدم الاستعلامات المجهزة (Prepared Statements) أو الإجراءات المخزنة (Stored Procedures). تجنب دمج المدخلات مباشرة في استعلامات SQL. تأكد من التحقق من صحة المدخلات (Input Validation).'
  },
  { 
    id: 'VULN-002', 
    target: 'admin.target.com', 
    type: 'IDOR', 
    severity: 'High', 
    date: '2023-10-24', 
    status: 'Open',
    description: 'مرجع كائن مباشر غير آمن (IDOR)، يحدث عندما يوفر التطبيق وصولاً مباشراً إلى الكائنات (مثل الملفات أو بيانات المستخدمين) بناءً على مدخلات المستخدم دون التحقق من الصلاحيات.',
    remediation: 'تنفيذ فحوصات التحكم في الوصول (Access Control) لكل طلب للتحقق من أن المستخدم الحالي لديه صلاحية الوصول إلى الكائن المطلوب. لا تعتمد فقط على إخفاء الروابط.'
  },
  { 
    id: 'VULN-003', 
    target: 'dev.target.com', 
    type: 'Exposed .git', 
    severity: 'High', 
    date: '2023-10-23', 
    status: 'Open',
    description: 'ترك مجلد .git متاحاً للعامة، مما يسمح للمهاجمين بتنزيل الكود المصدري للتطبيق بالكامل، والذي قد يحتوي على كلمات مرور ومفاتيح API حساسة.',
    remediation: 'قم بتقييد الوصول إلى مجلد .git في إعدادات خادم الويب (مثل قواعد Nginx أو ملف .htaccess في Apache) أو تأكد من إزالته تماماً من بيئة الإنتاج (Production).'
  },
  { 
    id: 'VULN-004', 
    target: 'shop.target.com', 
    type: 'Reflected XSS', 
    severity: 'Medium', 
    date: '2023-10-22', 
    status: 'Resolved',
    description: 'ثغرة البرمجة عبر المواقع الانعكاسية (XSS)، تسمح للمهاجم بتنفيذ نصوص برمجية (JavaScript) خبيثة في متصفح الضحية عند النقر على رابط ملغوم.',
    remediation: 'قم بتنقية (Sanitize) وتشفير (Encode) جميع المدخلات قبل عرضها للمستخدم في صفحة الويب. استخدم ترويسة Content-Security-Policy (CSP) كطبقة حماية إضافية.'
  },
  { 
    id: 'VULN-005', 
    target: 'blog.target.com', 
    type: 'Open Redirect', 
    severity: 'Low', 
    date: '2023-10-21', 
    status: 'Open',
    description: 'إعادة توجيه مفتوحة تسمح للمهاجم بإعادة توجيه المستخدمين إلى مواقع خبيثة (للتصيد الاحتيالي) باستخدام روابط تبدو وكأنها تابعة لموقعك الموثوق.',
    remediation: 'تجنب استخدام المدخلات المباشرة لتحديد وجهة إعادة التوجيه. إذا كان لابد من ذلك، استخدم قائمة بيضاء (Whitelist) للروابط والنطاقات المسموح بها فقط.'
  },
];

export const terminalLogs = [
  "[+] Starting Amass Recon for target.com...",
  "[+] Found 145 subdomains.",
  "[+] Resolving active hosts...",
  "[+] 89 active hosts found. Passing to HTTPX...",
  "[+] 45 HTTP servers responding.",
  "[+] Initiating Nuclei templates (cves, default logins, misconfigs)...",
  "[!] [CVE-2021-44228] Log4j JNDI RCE found on api.target.com",
  "[!] [XSS] Reflected XSS found on shop.target.com/?q=",
  "[*] AI Filter: Analyzing results for false positives...",
  "[-] AI Filter: Dropped 3 false positive XSS alerts.",
  "[+] Scan complete. Results saved to dashboard."
];
